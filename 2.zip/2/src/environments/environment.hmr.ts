export const environment = {
    production: false,
    hmr       : true,
    backendUrl: 'http://localhost',
    backendPort:'9001',
    app:'CRA'
};
