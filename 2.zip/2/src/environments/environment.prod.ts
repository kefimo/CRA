export const environment = {
    production: true,
    hmr       : false,
    backendUrl: 'http://localhost',
    backendPort:'9001',
    app:'CRA'
};
