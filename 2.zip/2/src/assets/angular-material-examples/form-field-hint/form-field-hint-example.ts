import {Component} from '@angular/core';

/** @title Form field with hints */
@Component({
  selector: 'form-field-hint-example',
  templateUrl: 'form-field-hint-example.html',
  styleUrls: ['form-field-hint-example.css'],
})
export class FormFieldHintExample {}
