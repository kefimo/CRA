import {Component} from '@angular/core';

/**
 * @title Basic divider
 */
@Component({
  selector: 'divider-overview-example',
  templateUrl: 'divider-overview-example.html',
  styleUrls: ['divider-overview-example.css'],
})
export class DividerOverviewExample {}
