import {Component} from '@angular/core';

/** @title Select with no option ripple */
@Component({
  selector: 'select-no-ripple-example',
  templateUrl: 'select-no-ripple-example.html',
  styleUrls: ['select-no-ripple-example.css'],
})
export class SelectNoRippleExample {}
