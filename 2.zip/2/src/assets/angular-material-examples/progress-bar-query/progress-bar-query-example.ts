import {Component} from '@angular/core';

/**
 * @title Query progress-bar
 */
@Component({
  selector: 'progress-bar-query-example',
  templateUrl: 'progress-bar-query-example.html',
  styleUrls: ['progress-bar-query-example.css'],
})
export class ProgressBarQueryExample {}
